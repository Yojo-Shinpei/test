package jp.co.internous.antion;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

		System.out.println("HelloWorld!");
	}

}
